package com.example.choices;

public class StoryModel {

    private String storyName;



    public StoryModel( String storyName){

        this.storyName =  storyName;
    }

    public String getStoryName() {
        return storyName;
    }

    public void setStoryName(String storyName) {
        this.storyName = storyName;
    }
}
